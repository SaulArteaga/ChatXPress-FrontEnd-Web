/**
 * We create a constant used to store the data of the administrator
 * (later we will change it to the database data).
 */

export const adminUser = {
  name: "admin",
  password: "undostres",
};
