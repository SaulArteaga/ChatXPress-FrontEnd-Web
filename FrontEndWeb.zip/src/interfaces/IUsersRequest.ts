export interface IUsersRequest {
  department?: string;
  email?: string;
  lastname?: string;
  name?: string;
  password?: string;
}
