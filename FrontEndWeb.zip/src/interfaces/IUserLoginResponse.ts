export interface IUserLoginResponse {
  username: String;
  email: String;
  token: string;
}
