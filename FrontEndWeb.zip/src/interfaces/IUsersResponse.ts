export interface IUsersResponse {
  _id: string;
  department: string;
  email: string;
  idRole: string;
  isActive: boolean;
  lastname: string;
  name: string;
  password: string;
}
