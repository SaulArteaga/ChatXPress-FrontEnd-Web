export interface IUserLoginRequest {
  email: String;
  password: String;
  nameRole: String;
}
